module.exports={
    server_port: 3000,
    
    pool:{
    connectionLimit:10,
    host:'localhost',
    user:'root',
    password:'root',
    database:'farm',
    debug:false
    }
}