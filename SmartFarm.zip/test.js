 var regx=/^[a-zA-Z0-9]*\s[0-9]*\s[0-9]*$/
 var str='b1 27 55';

console.log(regx.test(str));