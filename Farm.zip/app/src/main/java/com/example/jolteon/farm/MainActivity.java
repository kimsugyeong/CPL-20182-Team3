package com.example.jolteon.farm;

import android.support.v4.widget.TextViewCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    EditText editText;
    TextView textView;
    String operation="";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editText=(EditText) findViewById(R.id.editText);
        textView=(TextView) findViewById(R.id.textView);
    }

    public void controlButtonClicked(View v){
        String url="http://118.45.197.250:3000/controlArduino";

        switch (v.getId()){
            case R.id.ledOnButton:
                operation="On";
                break;
            case R.id.ledOffButton:
                operation="Off";
                break;
        }

        StringRequest request=new StringRequest(Request.Method.POST, url,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        Log.d("Response", response);
                    }
                },
                new Response.ErrorListener(){
                    @Override
                    public void onErrorResponse(VolleyError error){
                        error.printStackTrace();
                    }
                }
        ){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params=new HashMap<>();
                params.put("op", operation);

                return params;
            }
        };

        request.setShouldCache(false);
        Volley.newRequestQueue(this).add(request);
        println("웹 서버에 요청함 : "+url);

    }

    public void mOnClick(View v){
        String url=editText.getText().toString();

        StringRequest request=new StringRequest(Request.Method.GET, url,
                new Response.Listener<String>(){
                    @Override
                    public void onResponse(String response){
                        try{
                            println("onResponse() 호출됨");

                            JSONArray jarray=new JSONArray(response);

                            for(int i=0; i<jarray.length(); i++){
                                JSONObject jObject=jarray.getJSONObject(i);
                                String date=jObject.getString("date");
                                int temperature=jObject.getInt("temperature");
                                int humidity=jObject.getInt("humidity");

                                println(date+", "+temperature+", "+humidity);
                            }

                        } catch(Exception e){
                            e.printStackTrace();
                        }
                    }
                },
        new Response.ErrorListener(){
            @Override
            public void onErrorResponse(VolleyError error){
                error.printStackTrace();
            }
        }
        ){
            @Override
            protected Map<String, String> getParams(){
                Map<String, String> params=new HashMap<>();

                return params;
            }
        };

        request.setShouldCache(false);
        Volley.newRequestQueue(this).add(request);
        println("웹 서버에 요청함 : "+url);
    }

    public void println(final String data){
        textView.append(data+'\n');
    }
}
